<?php
require_once __DIR__ . '/library/model-categories.php';


$systemMessage = '';

//ispod treba da ide obrada forme
//ako je forma uspesna $systemMessage treba da postane 'Celebrity has been saved!'



require __DIR__ . '/templates/layout/t-header.php';
require __DIR__ . '/templates/layout/t-nav.php';
require __DIR__ . '/templates/t-new-celeb.php';
require __DIR__ . '/templates/layout/t-footer.php';
?>