<?php 

function categoriesFetchAll() {

	return [
		[
			'id' => 2,
			'name' => 'Actors',
		],
		[
			'id' => 1,
			'name' => 'Singers',
		],
		[
			'id' => 3,
			'name' => 'Businessmen',
		],
	];
}

/**
 * 
 * @param int $id The id of category
 * @return array|NULL The category array or null if category does not exist
 */
function categoriesFetchOneById($id) {
    foreach (categoriesFetchAll() as $category) {
        if ($category['id'] == $id) {
            return $category;
        }
    }
    return null;
}
