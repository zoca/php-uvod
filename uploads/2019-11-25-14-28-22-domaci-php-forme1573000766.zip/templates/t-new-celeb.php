<h1>New celebrity</h1>

<div class="system-message">Celebrity has been saved!</div>

<form id="new-celeb-form" action="">

	<fieldset>
		<legend>Clebrity general info</legend>
		<div class="input-group">
			<label>Clebrity Name</label>
			<input type="text" name="celebrity_name" value="" required="required">
		</div>

		<div class="input-group">
			<label>Date of birth</label>
			<input type="text" name="celebrity_date_of_birth" value="" required="required">
		</div>

		<div class="input-group">
			<label>Date of death</label>
			<input type="date" name="celebrty_date_of_death" value="">
		</div>

		<div class="input-group">
			<label>Photo Url</label>
			<input type="url" name="celebrity_photo_url" value="">
		</div>
	</fieldset>

	<fieldset>
		<legend>Celebrity resume</legend>

		<textarea name="celebrity_resume" cols="50" rows="10" required="required"></textarea>
	</fieldset>

	<fieldset>
		<legend>Celebrity quote</legend>

		<textarea name="celebrity_quote" cols="50" rows="2" required="required"></textarea>
	</fieldset>

	<fieldset>
		<legend>Celebrity settings</legend>
		<div class="input-group">
			<label>Category</label>

			<select name="celebrity_category" required>
				<option value="">-- Select Category --</option>
				<option value="23">Singer</option>
				<option value="45">Businessman</option>
				<option value="61">Politician</option>
				<option value="33" selected>Actor</option>
			</select>
		</div>
		<div class="input-group">
			<label>Status</label>
			<div class="inline-options">

				<input type="radio" name="celebrity_status" value="A" id="act"> <label for="act">Active</label>
				<input type="radio" name="celebrity_status" value="D" id="dis"> <label for="dis">Disabled</label>
			</div>
		</div>
	</fieldset>

	<fieldset class="form-footer">
		<button type="reset">Clear</button>
		<button type="submit">Save Celebrity</button>
	</fieldset>

</form>

</main>