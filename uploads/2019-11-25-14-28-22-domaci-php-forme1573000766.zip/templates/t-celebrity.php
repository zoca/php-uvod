<h1>Celebrity: <?php echo htmlspecialchars($celebrity['name']);?></h1>
<article class="celeb">
	<div>
		<div class="celeb-image">
			<a href="#">
				<img src="/theme/assets/images/<?php echo htmlspecialchars($celebrity['image']);?>" 
					 alt="<?php echo htmlspecialchars($celebrity['name']);?>">
			</a>
		</div>

		<div class="celeb-resume">
			<p>
				<strong><?php echo htmlspecialchars($celebrity['full_name']);?></strong> 
				(born <?php echo htmlspecialchars(date('d M Y', strtotime($celebrity['date_of_birth'])));
			echo!empty($celebrity['date_of_death']) ? ' - ' . htmlspecialchars(date('d M Y', strtotime($celebrity['date_of_death']))) : ''; ?>)
				<?php echo htmlspecialchars($celebrity['biography']);?>
			</p>
		</div>
	</div>
	<div>
		<blockquote>"<?php echo htmlspecialchars($celebrity['quote']);?>"</blockquote>
	</div>
</article>