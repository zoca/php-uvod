   <head>
        <title>Celebrities quotes</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Marck+Script|Questrial">
        <link rel="stylesheet" type="text/css" href="/theme/assets/css/main.css">
        <link rel="stylesheet" type="text/css" href="/theme/assets/css/form.css">
        <link rel="shortcut icon" type="image/x-icon" href="/theme/assets/images/favicon.ico">
    </head>

    <body>

        <header>
            <div id="logo">
                <a href="/index.php"><img src="/theme/assets/images/logo.png" alt="logo"></a>
            </div>
            <div id="site-title">
                Celebrities quotes
            </div>
        </header>
