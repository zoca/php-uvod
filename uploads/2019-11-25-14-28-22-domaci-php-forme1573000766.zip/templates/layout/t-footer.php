<?php
include_once __DIR__ . '/library/model-celebrities.php';

$randomCelebrity = celebritiesFetchOneRandom();

?>
</main>

        <aside>
            <h2>Quote of the day</h2>
            <blockquote>
                <?php echo htmlspecialchars($randomCelebrity['quote'])?>
            </blockquote>
            <p><small><?php echo htmlspecialchars($randomCelebrity['name'])?></small></p>
        </aside>

        <footer>
            &copy; Celebrities quotes 2019
        </footer>

    </body>


</html>
