<?php

$allCategories = categoriesFetchAll();
?>

<nav>         <!-- ///////A-Z order///////-->
            <ul>
                <li>
                    <a href="/index.php">All celebrities</a>
                </li>
                <?php foreach ($allCategories as $oneCategory) {?>
                <li>
                    <a href="/category.php?id=<?php echo htmlspecialchars($oneCategory['id']);?>">
                    <?php echo htmlspecialchars($oneCategory['name']);?>
                    </a>
                </li>
                <?php }?>
                <li class="celeb-add-new">
                    <a href="/new-celeb.php">New Celebrity</a>
                </li>

            </ul>
        </nav>

        <main>