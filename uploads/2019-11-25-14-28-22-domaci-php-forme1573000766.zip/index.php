<?php
require_once __DIR__ . '/library/model-celebrities.php';
require_once __DIR__ . '/library/model-categories.php';

$celebrities = celebritiesFetchAll();

require __DIR__ . '/templates/layout/t-header.php';
require __DIR__ . '/templates/layout/t-nav.php';
require __DIR__ . '/templates/t-index.php';
require __DIR__ . '/templates/layout/t-footer.php';
?>