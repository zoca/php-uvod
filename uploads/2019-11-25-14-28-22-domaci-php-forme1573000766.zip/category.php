<?php
require_once __DIR__ . '/library/model-categories.php';
require_once __DIR__ . '/library/model-celebrities.php';

if (empty($_GET['id'])) {
    die('Molim vas izaberite kategoriju');
}

$categoryId = $_GET['id'];

$category = categoriesFetchOneById($categoryId);

if (is_null($category)) {
    die('Kategorija nije pronadjena');
}


$celebrities = celebritiesFetchByCategory($categoryId);


require __DIR__ . '/templates/layout/t-header.php';
require __DIR__ . '/templates/layout/t-nav.php';
require __DIR__ . '/templates/t-category.php';
require __DIR__ . '/templates/layout/t-footer.php';
?>